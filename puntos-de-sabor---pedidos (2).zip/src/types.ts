/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  restaurant: string;
  description?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export type OrderStatus = 'PENDING' | 'READY' | 'DELIVERED';
export type OrderType = 'MESA' | 'PARA LLEVAR';

export interface Order {
  id: string;
  code: string;
  pointId: string;
  pointName: string;
  items: CartItem[];
  type: OrderType;
  table?: string;
  notes?: string;
  customerName: string;
  customerPhone: string;
  subtotal: number;
  tax: number;
  total: number;
  status: OrderStatus;
  createdAt: string;
}

export interface Point {
  id: string;
  name: string;
  icon: string;
  color: string;
}

export const POINTS: Point[] = [
  { id: 'banderitas', name: 'Banderitas', icon: 'Flag', color: 'bg-[#002D62]' },
  { id: 'punto-wok', name: 'Punto Wok', icon: 'Flame', color: 'bg-emerald-700' },
  { id: 'kioskos', name: 'Kioskos Parrilla', icon: 'Beef', color: 'bg-amber-700' },
  { id: 'terraza', name: 'Terraza Living Lab', icon: 'Leaf', color: 'bg-[#2E7D32]' },
  { id: 'embarcadero', name: 'El Embarcadero', icon: 'Anchor', color: 'bg-blue-800' },
];
