/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import PointSelection from './components/PointSelection';
import Menu from './components/Menu';
import KitchenView from './components/KitchenView';
import { ManagementView } from './components/ManagementView';
import { Point, Product, CartItem } from './types';
import { AnimatePresence, motion } from 'motion/react';
import { ChefHat, ShoppingBag, Database } from 'lucide-react';

type Screen = 'selection' | 'pos' | 'kitchen' | 'management';

export default function App() {
  const [screen, setScreen] = useState<Screen>('selection');
  const [selectedPoint, setSelectedPoint] = useState<Point | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);

  const handlePointSelect = (point: Point) => {
    setSelectedPoint(point);
    setScreen('pos');
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === productId);
      if (existing && existing.quantity > 1) {
        return prev.map(item => 
          item.id === productId ? { ...item, quantity: item.quantity - 1 } : item
        );
      }
      return prev.filter(item => item.id !== productId);
    });
  };

  const clearCart = () => setCart([]);

  const completeOrder = () => {
    setCart([]);
    setScreen('selection');
    setSelectedPoint(null);
  };

  return (
    <div className="min-h-screen font-sans flex flex-col">
      {/* Universal Mode Selector Floating */}
      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 flex bg-[#002D62]/90 backdrop-blur-xl p-2 rounded-[2.5rem] border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
        <button 
          onClick={() => setScreen('selection')}
          className={`flex items-center gap-3 px-8 py-3.5 rounded-[2rem] text-[10px] font-black uppercase tracking-[0.2em] transition-all duration-500 ${screen !== 'kitchen' && screen !== 'management' ? 'bg-[#2E7D32] text-white shadow-xl shadow-green-900/40 scale-105' : 'text-white/40 hover:text-white'}`}
        >
          <ShoppingBag size={18} strokeWidth={2.5} />
          <span>Frente de Servicio</span>
        </button>
        <button 
          onClick={() => setScreen('kitchen')}
          className={`flex items-center gap-3 px-8 py-3.5 rounded-[2rem] text-[10px] font-black uppercase tracking-[0.2em] transition-all duration-500 ${screen === 'kitchen' ? 'bg-[#2E7D32] text-white shadow-xl shadow-green-900/40 scale-105' : 'text-white/40 hover:text-white'}`}
        >
          <ChefHat size={18} strokeWidth={2.5} />
          <span>Control Logístico</span>
        </button>
        <button 
          onClick={() => setScreen('management')}
          className={`flex items-center gap-3 px-8 py-3.5 rounded-[2rem] text-[10px] font-black uppercase tracking-[0.2em] transition-all duration-500 ${screen === 'management' ? 'bg-[#2E7D32] text-white shadow-xl shadow-green-900/40 scale-105' : 'text-white/40 hover:text-white'}`}
        >
          <Database size={18} strokeWidth={2.5} />
          <span>Gestión & Contable</span>
        </button>
      </div>

      <div className="flex-1 overflow-hidden h-screen">
        <AnimatePresence mode="wait">
          {screen === 'selection' && (
            <motion.div
              key="selection"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="h-full overflow-y-auto"
            >
              <PointSelection onSelect={handlePointSelect} />
            </motion.div>
          )}

          {screen === 'pos' && selectedPoint && (
            <motion.div
              key="pos"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="h-full"
            >
              <Menu 
                point={selectedPoint} 
                cart={cart}
                addToCart={addToCart}
                removeFromCart={removeFromCart}
                clearCart={clearCart}
                onComplete={completeOrder}
                onBack={() => setScreen('selection')}
              />
            </motion.div>
          )}

          {screen === 'kitchen' && (
            <motion.div
              key="kitchen"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="h-full"
            >
              <KitchenView />
            </motion.div>
          )}

          {screen === 'management' && (
            <motion.div
              key="management"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="h-full"
            >
              <ManagementView onBack={() => setScreen('selection')} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

