/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Order, OrderStatus } from '../types';
import { formatCurrency, cn } from '../lib/utils';
import { ChefHat, Clock, CheckCircle2, Trash2, Phone, MessageSquare, AlertCircle } from 'lucide-react';

import { Logo } from './Logo';

export default function KitchenView() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/orders');
      const data = await res.json();
      setOrders(data);
    } catch (err) {
      console.error('Error fetching orders:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
    const interval = setInterval(fetchOrders, 5000); // Poll every 5s
    return () => clearInterval(interval);
  }, []);

  const updateStatus = async (id: string, status: OrderStatus) => {
    try {
      await fetch(`/api/orders/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      fetchOrders();
    } catch (err) {
      console.error('Error updating status:', err);
    }
  };

  const deleteOrder = async (id: string) => {
    if (!confirm('¿Seguro que desea eliminar este pedido?')) return;
    try {
      await fetch(`/api/orders/${id}`, { method: 'DELETE' });
      fetchOrders();
    } catch (err) {
      console.error('Error deleting order:', err);
    }
  };

  const clearAll = async () => {
    if (!confirm('Esta acción borrará TODOS los pedidos del sistema. ¿Continuar?')) return;
    try {
      await fetch('/api/orders', { method: 'DELETE' });
      fetchOrders();
    } catch (err) {
      console.error('Error clearing orders:', err);
    }
  };

  const pendingOrders = orders.filter(o => o.status === 'PENDING').sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  const readyOrders = orders.filter(o => o.status === 'READY');

  return (
    <div className="h-screen flex flex-col bg-brand-muted font-sans text-white overflow-hidden">
      <header className="bg-[#002D62] text-white px-8 py-5 flex items-center justify-between shrink-0 shadow-2xl relative z-10">
        <div className="flex items-center gap-6">
           <Logo className="w-24" />
          <div>
            <h1 className="text-xl font-black uppercase tracking-widest text-white">Dashboard de Cocina</h1>
            <p className="text-[10px] text-white/60 font-black uppercase tracking-[0.2em] flex items-center gap-2 mt-0.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#2E7D32] animate-pulse" />
              Sincronización Logística en Tiempo Real
            </p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="text-right hidden sm:block">
            <p className="text-[9px] font-black text-white/40 uppercase tracking-widest mb-0.5">Estado del Servidor</p>
            <p className="text-xs font-mono font-bold text-white/80">LATENCY: 14MS • SSL: OK</p>
          </div>
          <div className="h-10 w-px bg-white/10" />
          <button 
            onClick={clearAll}
            className="flex items-center gap-3 bg-red-500/20 hover:bg-red-500 text-red-200 hover:text-white px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg shadow-black/20 group"
          >
            <Trash2 size={16} className="group-hover:rotate-12 transition-transform" />
            Reiniciar Jornada
          </button>
        </div>
      </header>

      <main className="flex-1 p-8 grid grid-cols-1 lg:grid-cols-2 gap-8 overflow-hidden">
        {/* En Preparación */}
        <div className="flex flex-col gap-6 overflow-hidden">
          <div className="flex items-center justify-between px-3">
            <h2 className="text-xs font-black text-white uppercase tracking-[0.3em] flex items-center gap-3">
              <span className="w-3 h-3 rounded-full bg-blue-400 shadow-[0_0_10px_rgba(96,165,250,0.5)]" />
              En Preparación ({pendingOrders.length})
            </h2>
            <div className="bg-white/10 backdrop-blur-md px-3 py-1 rounded-full flex items-center gap-2 border border-white/5">
               <Clock size={14} className="text-white/60" />
               <span className="text-[10px] font-mono font-black text-white/80 uppercase tracking-widest">Sinc Real</span>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto space-y-5 pr-2 scrollbar-thin scrollbar-thumb-white/20 scrollbar-track-transparent">
            <AnimatePresence mode="popLayout">
              {pendingOrders.map((order) => (
                <motion.div
                  key={order.id}
                  layout
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
                  className="bg-white rounded-3xl border-l-[12px] border-[#002D62] shadow-xl shadow-slate-200/50 p-6 border border-slate-200 relative group overflow-hidden"
                >
                  {/* Background Decoration */}
                  <div className="absolute right-0 top-0 w-32 h-32 bg-[#002D62]/5 rounded-full translate-x-16 -translate-y-16 group-hover:scale-110 transition-transform duration-500 opacity-50" />
                  
                  <div className="flex justify-between items-start mb-6 relative z-10">
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="text-3xl font-black text-[#002D62] tracking-tighter">#{order.code}</span>
                        <span className="text-[9px] font-black text-[#002D62] bg-blue-50 px-2 py-0.5 rounded-lg uppercase tracking-widest">ID: {order.id.slice(0,4)}</span>
                      </div>
                      <p className="text-[10px] font-black text-[#002D62]/50 uppercase tracking-[0.2em] mt-2 flex items-center gap-2">
                        <span className="text-[#002D62]">{order.pointName}</span>
                         <span className="w-1 h-1 bg-[#002D62]/20 rounded-full" /> 
                         {order.type} {order.table ? <span className="text-[#002D62]">Mesa {order.table}</span> : ''}
                      </p>
                    </div>
                    <div className="bg-[#002D62]/5 p-2 rounded-2xl border border-[#002D62]/10 flex flex-col items-center min-w-[70px]">
                      <p className="text-[8px] font-black text-[#002D62]/40 uppercase tracking-widest leading-none mb-1">Recibido</p>
                      <p className="text-sm font-mono font-black text-[#002D62]">
                        {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>

                  <div className="bg-[#F8F9FA] rounded-2xl p-5 mb-6 border border-slate-100 relative z-10">
                    <ul className="space-y-4">
                      {order.items.map((item, idx) => (
                        <li key={idx} className="flex justify-between items-center group/item">
                          <div className="flex items-center gap-4">
                            <span className="w-10 h-10 bg-[#002D62] text-white rounded-xl flex items-center justify-center font-black text-base shadow-lg shadow-blue-900/20 group-hover/item:scale-110 transition-transform">
                              {item.quantity}
                            </span>
                            <span className="font-black text-slate-700 uppercase text-sm tracking-tight leading-none">{item.name}</span>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {order.notes && (
                    <div className="flex gap-4 p-4 bg-amber-50 rounded-2xl border border-amber-100 mb-6 items-start relative z-10">
                      <MessageSquare size={18} className="text-amber-500 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-[9px] font-black text-amber-600/60 uppercase tracking-widest mb-1">Notas de Logística</p>
                        <p className="text-xs font-bold text-slate-700 leading-relaxed italic">"{order.notes}"</p>
                      </div>
                    </div>
                  )}

                  <button 
                    onClick={() => updateStatus(order.id, 'READY')}
                    className="w-full bg-emerald-500 hover:bg-emerald-600 text-white py-5 rounded-2xl font-black uppercase text-xs tracking-[0.2em] shadow-xl shadow-emerald-500/20 transition-all active:scale-[0.98] flex items-center justify-center gap-3 relative z-10"
                  >
                    <CheckCircle2 size={20} />
                    Completar Pedido
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
            {pendingOrders.length === 0 && !loading && (
              <div className="h-full flex flex-col items-center justify-center text-white/40 gap-6 border-4 border-dashed border-white/10 rounded-[3rem] bg-black/10">
                <ChefHat size={80} strokeWidth={1} className="opacity-50" />
                <div className="text-center">
                  <p className="font-black uppercase tracking-[0.3em] text-sm text-white/80">Parrilla Limpia</p>
                  <p className="text-[10px] font-bold text-white/60 uppercase tracking-widest mt-2">No hay órdenes en línea en este momento</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Listos para Entrega */}
        <div className="flex flex-col gap-6 overflow-hidden">
          <div className="flex items-center justify-between px-3">
             <h2 className="text-xs font-black text-white uppercase tracking-[0.3em] flex items-center gap-3">
              <span className="w-3 h-3 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.5)]" />
              Notificados ({readyOrders.length})
            </h2>
          </div>

          <div className="flex-1 overflow-y-auto space-y-4 pr-2 scrollbar-thin scrollbar-thumb-white/20 scrollbar-track-transparent">
            <AnimatePresence mode="popLayout">
              {readyOrders.map((order) => (
                <motion.div
                  key={order.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-white rounded-3xl border border-emerald-100 p-5 shadow-lg shadow-emerald-500/5 relative overflow-hidden group"
                >
                  <div className="absolute right-0 top-0 w-24 h-full bg-emerald-500/5 -skew-x-12 translate-x-12" />
                  
                  <div className="flex justify-between items-center relative z-10">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 bg-emerald-50 border-2 border-emerald-100 rounded-2xl flex items-center justify-center">
                        <span className="text-xl font-black text-emerald-700">{order.code}</span>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                           <span className="text-[9px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-100 px-2 py-0.5 rounded-full">Listo para Entrega</span>
                        </div>
                        <p className="text-xs font-black text-slate-700 uppercase tracking-tight mt-1.5 leading-none">
                          {order.customerName}
                        </p>
                        <p className="text-[10px] font-mono font-bold text-slate-400 uppercase mt-1">Sinc: {order.customerPhone}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => updateStatus(order.id, 'DELIVERED')}
                        className="bg-[#002D62] hover:bg-blue-900 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-blue-900/20 transition-all active:scale-95"
                      >
                        Entregado
                      </button>
                      <button 
                        onClick={() => deleteOrder(order.id)}
                        className="bg-black/5 border border-black/10 text-white/30 p-3 rounded-xl hover:text-red-500 hover:bg-red-50 transition-all"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
            {readyOrders.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-white/40 gap-6 border-4 border-dashed border-white/10 rounded-[3rem] bg-black/10">
                <CheckCircle2 size={80} strokeWidth={1} />
                <p className="font-black uppercase tracking-[0.3em] text-sm text-white/80">Todo al Día</p>
              </div>
            )}
          </div>
        </div>
      </main>

      <footer className="bg-[#002D62] border-t border-white/5 px-8 py-3 flex justify-between items-center shrink-0">
        <div className="flex gap-10 text-[9px] font-black text-white/40 uppercase tracking-widest">
          <span className="flex items-center gap-3"><span className="text-white/60">Operación:</span> Puntos de Sabor</span>
          <span className="flex items-center gap-3"><span className="text-white/60">Shift ID:</span> PS-LOG-01</span>
        </div>
        <div className="flex items-center gap-3 text-[9px] text-white/50 font-black uppercase tracking-[0.2em]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#2E7D32]" />
          Conexión Segura
        </div>
      </footer>
    </div>
  );
}
