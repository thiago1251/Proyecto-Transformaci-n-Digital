/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Product, Point, CartItem, OrderType } from '../types';
import { PRODUCTS } from '../data/products';
import { formatCurrency, cn } from '../lib/utils';
import { Plus, Minus, Search, Trash2, Send, CheckCircle2, ChevronDown, Phone, ShoppingBasket, Inbox, User, Flag, Flame, Beef, Leaf, Anchor, AlertCircle } from 'lucide-react';

import { Logo } from './Logo';

interface MenuProps {
  point: Point;
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  onComplete: () => void;
  onBack: () => void;
}

const RESTAURANT_ICONS: Record<string, any> = {
  'Banderitas': Flag,
  'Punto Wok': Flame,
  'Kioskos Parrilla': Beef,
  'Terraza Living Lab': Leaf,
  'Embarcadero': Anchor
};

export default function Menu({ point, cart, addToCart, removeFromCart, clearCart, onComplete, onBack }: MenuProps) {
  // Use the point's name to filter products by restaurant
  const currentRestaurant = useMemo(() => {
    // Standardize naming if they differ slightly
    const mapped = PRODUCTS.find(p => p.restaurant.toLowerCase().includes(point.id.toLowerCase()))?.restaurant || point.name;
    return mapped;
  }, [point]);

  const restaurantProducts = useMemo(() => 
    PRODUCTS.filter(p => p.restaurant === currentRestaurant),
    [currentRestaurant]
  );

  const CATEGORIES = useMemo(() => 
    Array.from(new Set(restaurantProducts.map(p => p.category))),
    [restaurantProducts]
  );

  const [activeCategory, setActiveCategory] = useState<string>(CATEGORIES[0] || '');
  const [searchQuery, setSearchQuery] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [table, setTable] = useState('');
  const [notes, setNotes] = useState('');
  const [orderType, setOrderType] = useState<OrderType>('MESA');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const filteredProducts = restaurantProducts.filter(p => 
    (activeCategory === '' || p.category === activeCategory) && 
    (p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
     p.description?.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * 0.19;
  const total = subtotal + tax;

  const RestIcon = RESTAURANT_ICONS[currentRestaurant] || Flag;

  const handleFinish = async () => {
    if (!phoneNumber || cart.length === 0 || isSubmitting) return;
    setIsSubmitting(true);
    setError(null);

    try {
      const orderPayload = {
        pointId: point.id,
        pointName: point.name,
        items: cart,
        type: orderType,
        table,
        notes,
        customerName,
        customerPhone: phoneNumber,
        subtotal,
        tax,
        total
      };

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderPayload)
      });
      
      if (!res.ok) throw new Error('Error al crear el pedido');
      
      const order = await res.json();

      if (order.whatsappError) {
        setError(`Pedido ${order.code} registrado, pero WhatsApp no se envió: ${order.whatsappError}`);
      } else {
        setIsSuccess(true);
      }

      clearCart();
      setPhoneNumber('');
      setCustomerName('');
      setTable('');
      setNotes('');
      
      setTimeout(() => {
        setIsSuccess(false);
        setError(null);
      }, 6000);

    } catch (err: any) {
      console.error('Error submitting order:', err);
      setError(err.message || 'Error al conectar con el servidor. Verifique su conexión.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="h-screen flex flex-col bg-brand-muted font-sans text-white overflow-hidden relative">
      {/* Toast Notification */}
      <AnimatePresence>
        {isSuccess && (
          <motion.div 
            initial={{ y: -100, opacity: 0 }}
            animate={{ y: 20, opacity: 1 }}
            exit={{ y: -100, opacity: 0 }}
            className="fixed top-0 left-1/2 -translate-x-1/2 z-[100] px-8 py-4 bg-[#2E7D32] text-white rounded-2xl shadow-2xl flex items-center gap-4 border border-white/20"
          >
            <CheckCircle2 size={24} />
            <div className="flex flex-col">
              <span className="text-sm font-black uppercase tracking-widest">Factura Enviada</span>
              <span className="text-[10px] opacity-80 font-bold uppercase">Mensaje enviado vía WhatsApp</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Header */}
      <header className="bg-[#002D62] border-b border-white/10 px-6 py-3 flex items-center justify-between shrink-0 shadow-xl z-20 text-white">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-4">
            <Logo className="w-24" />
            <div className="h-8 w-px bg-white/10" />
            <button 
              onClick={onBack}
              className="group flex items-center gap-4 hover:opacity-80 transition-all text-white"
            >
              <div className="w-10 h-10 bg-white/10 backdrop-blur-md rounded-xl flex items-center justify-center text-white shadow-xl group-hover:scale-105 transition-transform">
                 <RestIcon size={20} />
              </div>
              <div className="hidden sm:block text-left">
                <h1 className="text-base font-black leading-tight uppercase tracking-tight text-white">{currentRestaurant}</h1>
                <p className="text-[8px] font-bold text-white/40 uppercase tracking-widest leading-none">Punto de Venta</p>
              </div>
            </button>
          </div>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="flex flex-col items-end">
            <span className="text-[8px] font-black text-white/40 uppercase tracking-widest">Punto de Entrega</span>
            <span className="text-sm font-black text-white flex items-center gap-1">
              {point.name} <ChevronDown size={14} className="text-white/30" />
            </span>
          </div>
          <div className="h-8 w-px bg-white/10" />
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-xs font-black text-white">Operador Autorizado</p>
              <p className="text-[9px] text-white/60 uppercase font-mono font-bold">Terminal ID: 742-U</p>
            </div>
            <div className="w-10 h-10 bg-white/10 rounded-full border border-white/20 flex items-center justify-center text-white">
              <User size={20} strokeWidth={2.5} />
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden">
        {/* Left Nav: Categories */}
        <nav className="w-64 bg-black/20 backdrop-blur-md border-r border-white/10 flex flex-col shrink-0">
          <div className="p-6 flex flex-col gap-2">
            <p className="text-[10px] font-black text-white/60 uppercase tracking-[0.2em] mb-4 px-2">Categorías</p>
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={cn(
                  "w-full text-left px-5 py-4 rounded-xl transition-all text-xs font-bold flex items-center justify-between group uppercase tracking-tight",
                  activeCategory === cat 
                    ? "bg-white text-[#002D62] shadow-xl shadow-black/20 translate-x-1" 
                    : "text-white/60 hover:bg-white/10 hover:text-white"
                )}
              >
                <span>{cat}</span>
                <span className={cn(
                  "text-[9px] px-2 py-0.5 rounded-md font-mono",
                  activeCategory === cat ? "bg-[#002D62]/10" : "bg-white/10"
                )}>
                  {restaurantProducts.filter(p => p.category === cat).length}
                </span>
              </button>
            ))}
          </div>
          <div className="mt-auto p-6 border-t border-white/5 bg-black/10">
            <div className="flex items-center gap-3 opacity-60">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[9px] font-black text-white/50 uppercase tracking-widest">Sincronización Activa</span>
            </div>
          </div>
        </nav>

        {/* Middle: Product Selection */}
        <section className="flex-1 flex flex-col bg-[#F8F9FA] overflow-hidden">
          <div className="p-8 pb-4 shrink-0 bg-[#002D62] shadow-xl">
            <div className="relative group">
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-white/40 group-focus-within:text-white transition-colors" size={20} />
              <input 
                type="text"
                placeholder="Buscar en el portafolio gastronómico..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/10 border border-white/20 rounded-2xl py-5 pl-14 pr-6 text-sm font-bold text-white placeholder:text-white/40 focus:ring-8 focus:ring-white/5 focus:border-white/40 transition-all outline-none shadow-sm"
              />
            </div>
            <div className="flex items-center gap-2 mt-5 text-[10px] font-black text-white/40 uppercase tracking-[0.2em] px-1">
              <span>Portafolio</span>
              <span className="text-white/20">/</span>
              <span className="text-white/80">{activeCategory}</span>
            </div>
          </div>

          <div className="flex-1 p-8 overflow-y-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              <AnimatePresence mode="popLayout">
                {filteredProducts.map((product) => (
                  <motion.button
                    key={product.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    onClick={() => addToCart(product)}
                    className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 hover:border-indigo-600 hover:shadow-2xl hover:shadow-indigo-600/10 transition-all text-left flex flex-col gap-5 group relative overflow-hidden"
                  >
                    {/* Hover Effect Layer */}
                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    
                    <div className="flex justify-between items-start relative z-10">
                      <span className={cn(
                        "text-[10px] font-black font-mono px-2.5 py-1 rounded-md uppercase tracking-wider",
                        product.category === 'Línea Verde' ? 'text-[#2E7D32] bg-green-50' : 'text-[#002D62] bg-blue-50'
                      )}>
                        {product.category}
                      </span>
                      <div className="w-10 h-10 rounded-xl bg-[#F8F9FA] flex items-center justify-center text-slate-400 group-hover:bg-[#002D62] group-hover:text-white transition-all duration-300">
                        <Plus size={20} strokeWidth={3} />
                      </div>
                    </div>
                    
                    <div className="relative z-10">
                      <h3 className="font-extrabold text-[#333333] text-lg leading-tight uppercase tracking-tight mb-2 group-hover:text-[#002D62] transition-colors">{product.name}</h3>
                      <p className="text-xs text-slate-500 font-medium leading-relaxed line-clamp-3">{product.description}</p>
                    </div>
                    
                    <div className="mt-auto pt-4 flex items-center justify-between border-t border-slate-50 relative z-10">
                      <span className="text-xl font-black text-[#002D62] tracking-tight">{formatCurrency(product.price)}</span>
                      {cart.find(i => i.id === product.id) ? (
                        <div className="flex items-center gap-2">
                           <span className="bg-[#2E7D32] text-white text-[10px] font-black px-3 py-1.5 rounded-lg animate-in zoom-in shadow-lg shadow-green-500/20">
                             {cart.find(i => i.id === product.id)?.quantity} EN CARRITO
                           </span>
                        </div>
                      ) : (
                        <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Añadir</span>
                      )}
                    </div>
                  </motion.button>
                ))}
              </AnimatePresence>
            </div>
          </div>
        </section>

        <aside className="w-[420px] bg-white border-l border-slate-200 flex flex-col shrink-0 shadow-2xl relative z-10">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-[#F8F9FA] shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#002D62] text-white rounded-xl flex items-center justify-center shadow-lg shadow-blue-900/20">
                <ShoppingBasket size={22} />
              </div>
              <div>
                <h2 className="font-black text-[#002D62] uppercase tracking-tighter">Mi Pedido</h2>
                <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Resumen de Cuenta</p>
              </div>
            </div>
            <button 
              onClick={clearCart}
              className="text-slate-300 hover:text-red-500 transition-colors p-2 rounded-xl hover:bg-red-50"
            >
              <Trash2 size={20} />
            </button>
          </div>

          <div className="flex-1 p-6 overflow-y-auto space-y-8">
            {/* Order Settings */}
            <div className="bg-black/5 p-1.5 rounded-2xl border border-dotted border-black/10 shadow-inner">
              <div className="flex">
                <button 
                  onClick={() => setOrderType('MESA')}
                  className={cn(
                    "flex-1 py-3 text-[10px] font-black uppercase tracking-[0.2em] rounded-xl transition-all",
                    orderType === 'MESA' ? "bg-white text-[#002D62] shadow-sm" : "text-slate-400 hover:text-slate-600"
                  )}
                >
                  Servicio a Mesa
                </button>
                <button 
                  onClick={() => setOrderType('PARA LLEVAR')}
                  className={cn(
                    "flex-1 py-3 text-[10px] font-black uppercase tracking-[0.2em] rounded-xl transition-all",
                    orderType === 'PARA LLEVAR' ? "bg-white text-[#002D62] shadow-sm" : "text-slate-400 hover:text-slate-600"
                  )}
                >
                  Para Llevar
                </button>
              </div>
            </div>

            <div className="space-y-6">
                 {orderType === 'MESA' && (
                  <div className="space-y-2 animate-in slide-in-from-top-4 duration-500">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1 flex items-center gap-2">
                       <ShoppingBasket size={12} /> Localización Mesa
                    </label>
                    <input 
                      type="text"
                      placeholder="Identificador (Ej: Terraza-04)"
                      value={table}
                      onChange={(e) => setTable(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4.5 px-6 text-base font-black text-[#002D62] placeholder:text-slate-300 focus:ring-8 focus:ring-[#002D62]/5 focus:border-[#002D62] outline-none transition-all shadow-sm"
                    />
                  </div>
                )}

                <div className="h-px bg-slate-100" />

                {cart.length === 0 ? (
                  <div className="py-20 flex flex-col items-center justify-center text-center space-y-6 opacity-30">
                    <div className="w-24 h-24 bg-black/5 rounded-[40%] flex items-center justify-center text-slate-300 border-2 border-dashed border-slate-300">
                      <Inbox size={48} strokeWidth={1} />
                    </div>
                    <div>
                      <p className="font-black text-slate-400 uppercase text-xs tracking-[0.3em]">Bandeja Vacía</p>
                      <p className="text-slate-300 text-[10px] mt-2 font-bold uppercase tracking-widest leading-loose">Explore el portafolio y<br/>añada productos para facturar</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-5">
                    <AnimatePresence>
                      {cart.map((item) => (
                        <motion.div 
                          key={item.id}
                          layout
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, scale: 0.95 }}
                          className="flex justify-between items-center group bg-black/5 p-3 rounded-2xl border border-transparent hover:border-slate-100 transition-all"
                        >
                          <div className="flex gap-4 items-center">
                            <div className="flex flex-col items-center gap-1.5">
                              <button onClick={() => addToCart(item)} className="p-1.5 bg-white text-slate-300 hover:text-[#002D62] rounded-lg shadow-sm hover:shadow-md transition-all"><Plus size={12} strokeWidth={3}/></button>
                              <span className="text-sm font-black bg-[#002D62] text-white w-8 h-8 flex items-center justify-center rounded-xl shadow-lg shadow-blue-900/20">{item.quantity}</span>
                              <button onClick={() => removeFromCart(item.id)} className="p-1.5 bg-white text-slate-300 hover:text-red-500 rounded-lg shadow-sm hover:shadow-md transition-all"><Minus size={12} strokeWidth={3}/></button>
                            </div>
                            <div>
                              <div className="text-sm font-black text-slate-800 uppercase tracking-tighter leading-none mb-1.5">{item.name}</div>
                              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                                 {formatCurrency(item.price)} <span className="text-slate-200">•</span> {item.category}
                              </div>
                            </div>
                          </div>
                          <div className="text-lg font-black text-[#002D62]">{formatCurrency(item.price * item.quantity)}</div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}
            </div>

            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest px-1">Notas de Cocina</label>
                <textarea 
                  placeholder="Ej: Sin cebolla, extra picante..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-black/5 border border-slate-200 rounded-xl py-3 px-4 text-xs font-bold focus:ring-4 focus:ring-[#002D62]/10 outline-none transition-all resize-none h-20"
                />
              </div>
            </div>
          </div>

          <div className="p-8 border-t border-slate-200 space-y-6 bg-black/5 backdrop-blur-md">
            {/* Customer Info */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">Titular Cuenta</label>
                <input 
                  type="text" 
                  placeholder="Nombre Cliente" 
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-2xl py-4 px-5 text-xs font-black text-slate-700 focus:ring-8 focus:ring-indigo-600/5 outline-none transition-all shadow-sm"
                />
              </div>
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">WhatsApp Sinc</label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={14} />
                  <input 
                    type="tel" 
                    placeholder="Móvil Destino" 
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="w-full pl-10 pr-4 py-4 bg-white border border-slate-200 rounded-2xl text-xs font-black text-slate-700 focus:ring-8 focus:ring-indigo-600/5 outline-none transition-all shadow-sm"
                  />
                </div>
              </div>
            </div>

            {/* Price Table */}
            <div className="space-y-2 px-1">
              <div className="flex justify-between text-[11px] font-bold text-slate-400 uppercase tracking-widest">
                <span>Subtotal Portafolio</span>
                <span>{formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between text-2xl font-black text-[#002D62] border-t-2 border-slate-200 pt-5 mt-4">
                <span className="uppercase tracking-tighter">Total</span>
                <span>{formatCurrency(total)}</span>
              </div>
              <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest text-center mt-2 italic">Valores en COP • IVA del 19% incl.</p>
            </div>

            {/* Finish Action */}
            <button 
              onClick={handleFinish}
              disabled={cart.length === 0 || !phoneNumber || isSubmitting}
              className="w-full bg-[#002D62] hover:bg-blue-900 disabled:bg-slate-200 disabled:text-slate-400 disabled:shadow-none text-white font-black py-6 rounded-2xl flex flex-col items-center justify-center transition-all shadow-xl shadow-blue-900/20 active:scale-[0.98] group"
            >
              <div className="flex items-center gap-3">
                {isSubmitting ? (
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 border-4 border-white/30 border-t-white rounded-full animate-spin" />
                    <span className="text-lg uppercase tracking-[0.2em]">Enviando...</span>
                  </div>
                ) : (
                  <>
                    <Send size={22} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                    <span className="text-xl uppercase tracking-[0.15em]">Confirmar Pedido</span>
                  </>
                )}
              </div>
              {!isSubmitting && <span className="text-[10px] font-black opacity-60 uppercase tracking-[0.25em] mt-1.5">Generar Factura Digital vWhatsApp</span>}
            </button>
            
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 text-red-600 text-xs font-bold uppercase tracking-tight"
              >
                <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center shrink-0">
                  <AlertCircle size={16} />
                </div>
                {error}
              </motion.div>
            )}
          </div>
        </aside>
      </main>

      {/* Footer */}
      <footer className="bg-[#002D62] text-white/40 px-8 py-3 text-[10px] font-black uppercase tracking-widest flex justify-between items-center shrink-0 border-t border-white/5">
        <div className="flex gap-12">
          <span className="flex items-center gap-3"><span className="text-white">Puntos de Sabor</span> <span className="w-1 h-1 bg-white/20 rounded-full" /> Gestión de Pedidos Digitales</span>
          <span className="flex items-center gap-3">Terminal: <span className="text-white font-mono">PS-742-U</span> <span className="w-1 h-1 bg-white/20 rounded-full" /> <span className="text-white">Status: En Línea</span></span>
        </div>
        <div className="flex items-center gap-3 text-white/60">
          <span className="w-2 h-2 rounded-full bg-[#2E7D32] animate-pulse shadow-[0_0_10px_rgba(46,125,50,0.8)]" />
          Conexión Segura
        </div>
      </footer>
    </div>
  );
}
