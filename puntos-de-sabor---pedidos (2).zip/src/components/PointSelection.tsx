/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { POINTS, Point } from '../types';
import { cn } from '../lib/utils';
import * as LucideIcons from 'lucide-react';

import { Logo } from './Logo';

interface PointSelectionProps {
  onSelect: (point: Point) => void;
}

export default function PointSelection({ onSelect }: PointSelectionProps) {
  return (
    <div className="min-h-screen bg-brand-muted flex flex-col items-center justify-center p-6 bg-[grid-slate-200/[0.04]] relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
        <div className="absolute -top-1/4 -right-1/4 w-1/2 h-1/2 bg-brand-deep/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-1/4 -left-1/4 w-1/2 h-1/2 bg-brand-ocean/5 rounded-full blur-3xl" />
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-4xl w-full text-center space-y-12"
      >
        <div className="space-y-6">
          {/* Logo Unisabana Dining */}
          <div className="flex justify-center">
            <motion.div 
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="relative"
            >
              <Logo className="w-80" />
              <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-white border border-slate-200 text-[#002D62] px-6 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.3em] shadow-lg whitespace-nowrap">
                Portal de Gestión Institucional
              </div>
            </motion.div>
          </div>
          
          <div className="space-y-2">
            <h1 className="text-2xl font-black text-white uppercase tracking-[0.1em]">Seleccione un Restaurante</h1>
            <p className="text-white/80 font-medium max-w-lg mx-auto">Bienvenido al ecosistema gastronómico institucional. Por favor elija el punto para el pedido.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {POINTS.map((point) => {
            // @ts-ignore - Dynamic icon access
            const Icon = LucideIcons[point.icon];
            
            return (
              <motion.button
                key={point.id}
                whileHover={{ y: -8, shadow: "0 25px 50px -12px rgb(0 50 100 / 0.15)" }}
                whileTap={{ scale: 0.97 }}
                onClick={() => onSelect(point)}
                className="group relative bg-white p-8 rounded-2xl border border-slate-200 shadow-sm hover:border-brand-ocean transition-all duration-500 flex flex-col items-center gap-6"
              >
                <div className={cn(
                  "w-20 h-20 rounded-2xl flex items-center justify-center text-white transition-all duration-500 shadow-lg",
                  point.color,
                  "group-hover:scale-110 group-hover:shadow-brand-ocean/20"
                )}>
                  {Icon && <Icon size={36} strokeWidth={1.5} />}
                </div>
                <div className="space-y-1.5">
                  <h3 className="text-xl font-black text-slate-800 tracking-tight">{point.name}</h3>
                  <div className="flex items-center gap-2 justify-center">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                    <span className="text-[10px] text-slate-400 uppercase tracking-[0.2em] font-bold font-mono">Terminal Autorizado</span>
                  </div>
                </div>
              </motion.button>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
}
