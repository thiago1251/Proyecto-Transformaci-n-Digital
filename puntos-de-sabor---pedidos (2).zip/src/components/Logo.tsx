import React from 'react';

interface LogoProps {
  className?: string;
  variant?: 'light' | 'dark';
}

export const Logo: React.FC<LogoProps> = ({ className = '' }) => {
  return (
    <img 
      src="https://i.postimg.cc/vDhpnKdt/Untitled-design.png" 
      alt="Unisabana Dining" 
      className={`object-contain ${className}`}
      referrerPolicy="no-referrer"
    />
  );
};
