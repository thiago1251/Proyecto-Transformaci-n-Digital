/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Download, Table, Trash2, ChevronLeft, Search, RefreshCw } from 'lucide-react';
import * as XLSX from 'xlsx';
import { Order, POINTS } from '../types';
import { Logo } from './Logo';

interface ManagementViewProps {
  onBack: () => void;
}

export const ManagementView: React.FC<ManagementViewProps> = ({ onBack }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/orders');
      if (response.ok) {
        const data = await response.json();
        setOrders(data.sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
      }
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleExportExcel = () => {
    // Transform orders for accounting
    const exportData = orders.map(order => ({
      'Código': order.code,
      'Fecha': new Date(order.createdAt).toLocaleString('es-CO'),
      'Punto': order.pointName,
      'Cliente': order.customerName,
      'Teléfono': order.customerPhone,
      'Tipo': order.type,
      'Mesa': order.table || 'N/A',
      'Productos': order.items.map(it => `${it.name} (x${it.quantity})`).join(', '),
      'Subtotal': order.subtotal,
      'IVA (8%)': order.tax,
      'Total': order.total,
      'Estado': order.status,
      'Notas': order.notes || ''
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Gestión de Pedidos");
    
    // Auto-size columns
    const colWidths = Object.keys(exportData[0] || {}).map(() => ({ wch: 15 }));
    ws['!cols'] = colWidths;

    XLSX.writeFile(wb, `Gestion_Pedidos_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const clearDatabase = async () => {
    if (confirm('¿Estás seguro de que deseas borrar TODA la base de datos de pedidos? Esta acción no se puede deshacer.')) {
      try {
        const response = await fetch('/api/orders', { method: 'DELETE' });
        if (response.ok) {
          setOrders([]);
        }
      } catch (error) {
        console.error('Error clearing orders:', error);
      }
    }
  };

  const filteredOrders = orders.filter(order => 
    order.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.pointName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="flex flex-col h-full bg-brand-muted text-white">
      {/* Header */}
      <header className="bg-[#002D62] border-b border-white/10 px-6 py-4 flex items-center justify-between sticky top-0 z-10 text-white">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-4">
            <button 
              onClick={onBack}
              className="p-2 hover:bg-white/10 rounded-xl transition-colors text-white"
            >
              <ChevronLeft size={24} />
            </button>
            <Logo className="w-24" />
          </div>
          <div className="h-8 w-px bg-white/10 hidden sm:block" />
          <div className="flex flex-col">
            <h1 className="text-xl font-black text-white flex items-center gap-2 uppercase tracking-tight">
              Control de Gestión & Sabor
            </h1>
            <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest px-1">Auditoría y Contabilidad Institucional</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <button
            onClick={fetchOrders}
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-[#002D62] bg-white rounded-xl hover:bg-white/90 transition-colors shadow-lg shadow-black/10"
          >
            <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
            Actualizar
          </button>
          
          <button
            onClick={handleExportExcel}
            disabled={orders.length === 0}
            className="flex items-center gap-2 px-6 py-2.5 text-xs font-bold text-white bg-[#2E7D32] rounded-xl hover:bg-green-700 transition-all shadow-lg shadow-green-900/40 disabled:opacity-50"
          >
            <Download size={18} />
            Exportar Excel
          </button>

          <button
            onClick={clearDatabase}
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-white bg-red-600 rounded-xl hover:bg-red-700 transition-colors shadow-lg shadow-red-900/20"
          >
            <Trash2 size={18} />
            Limpiar Base
          </button>
        </div>
      </header>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6">
        <div className="bg-white p-7 rounded-2xl shadow-xl relative overflow-hidden group">
          <div className="absolute right-0 top-0 w-24 h-24 bg-blue-50 rounded-full translate-x-12 -translate-y-12" />
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-2">Total Pedidos</p>
          <p className="text-4xl font-black text-[#002D62]">{orders.length}</p>
        </div>
        <div className="bg-white p-7 rounded-2xl shadow-xl relative overflow-hidden group">
          <div className="absolute right-0 top-0 w-24 h-24 bg-blue-50 rounded-full translate-x-12 -translate-y-12" />
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-2">Ventas Brutas</p>
          <p className="text-4xl font-black text-[#002D62]">
            {formatCurrency(orders.reduce((sum, o) => sum + o.total, 0))}
          </p>
        </div>
        <div className="bg-white p-7 rounded-2xl shadow-xl relative overflow-hidden group">
          <div className="absolute right-0 top-0 w-24 h-24 bg-green-50 rounded-full translate-x-12 -translate-y-12" />
          <p className="text-[10px] text-[#2E7D32] font-black uppercase tracking-widest mb-2">IVA Recaudado (19%)</p>
          <p className="text-4xl font-black text-[#2E7D32]">
            {formatCurrency(orders.reduce((sum, o) => sum + o.tax, 0))}
          </p>
        </div>
      </div>

      {/* Point of Sale Breakdown */}
      <div className="px-6 mb-6">
        <h2 className="text-xs font-black text-white mb-3 uppercase tracking-[0.2em] px-1 opacity-80">Resumen por Punto de Venta</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {POINTS.map(point => {
            const pointOrders = orders.filter(o => o.pointId === point.id);
            const pointTotal = pointOrders.reduce((sum, o) => sum + o.total, 0);
            return (
              <motion.div 
                key={point.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white p-4 rounded-xl shadow-lg border border-slate-100"
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className={`w-3 h-3 rounded-full ${point.color}`} />
                  <p className="text-xs font-bold text-slate-700 truncate">{point.name}</p>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="text-[10px] uppercase text-slate-400 font-semibold tracking-tight">Pedidos</p>
                    <p className="text-lg font-bold text-[#002D62] leading-tight">{pointOrders.length}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] uppercase text-slate-400 font-semibold tracking-tight">Ventas</p>
                    <p className="text-sm font-bold text-indigo-600 leading-tight truncate">
                      {formatCurrency(pointTotal).replace(',00', '')}
                    </p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 px-6 pb-6 overflow-hidden flex flex-col">
        <div className="bg-white rounded-xl shadow-2xl flex flex-col h-full overflow-hidden">
          <div className="p-4 border-b border-slate-100 bg-[#F8F9FA]">
            <div className="relative max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="text"
                placeholder="Buscar por código, cliente o punto..."
                className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-sm text-slate-700 placeholder:text-slate-400"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          <div className="flex-1 overflow-auto">
            <table className="w-full text-left border-collapse">
              <thead className="bg-[#002D62] sticky top-0 z-10 border-b border-white/10">
                <tr>
                  <th className="px-4 py-3 text-xs font-semibold text-white uppercase tracking-wider">Ref</th>
                  <th className="px-4 py-3 text-xs font-semibold text-white uppercase tracking-wider">Fecha</th>
                  <th className="px-4 py-3 text-xs font-semibold text-white uppercase tracking-wider">Punto / Cliente</th>
                  <th className="px-4 py-3 text-xs font-semibold text-white uppercase tracking-wider">Productos</th>
                  <th className="px-4 py-3 text-xs font-semibold text-white uppercase tracking-wider text-right">Total</th>
                  <th className="px-4 py-3 text-xs font-semibold text-white uppercase tracking-wider text-center">Estado</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {loading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i} className="animate-pulse">
                      <td colSpan={6} className="px-4 py-6 text-center text-slate-400">Cargando datos...</td>
                    </tr>
                  ))
                ) : filteredOrders.length > 0 ? (
                  filteredOrders.map((order) => (
                    <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{order.code}</td>
                      <td className="px-4 py-4 whitespace-nowrap text-xs text-slate-500">
                        {new Date(order.createdAt).toLocaleDateString('es-CO')}<br/>
                        {new Date(order.createdAt).toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="px-4 py-4">
                        <div className="text-sm font-medium text-slate-800">{order.pointName}</div>
                        <div className="text-xs text-slate-500">{order.customerName}</div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="text-xs text-slate-600 max-w-xs truncate">
                          {order.items.map(it => `${it.name} x${it.quantity}`).join(', ')}
                        </div>
                      </td>
                      <td className="px-4 py-4 text-right whitespace-nowrap text-sm font-semibold text-slate-900">
                        {formatCurrency(order.total)}
                      </td>
                      <td className="px-4 py-4 text-center">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          order.status === 'DELIVERED' ? 'bg-green-100 text-green-700' :
                          order.status === 'READY' ? 'bg-blue-100 text-blue-700' :
                          'bg-amber-100 text-amber-700'
                        }`}>
                          {order.status}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="px-4 py-12 text-center text-slate-400">
                      No se encontraron pedidos.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
