/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

// In-memory store for orders (resets on server restart)
let orders: any[] = [];
let lastOrderNum = 0;

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.get("/api/orders", (req, res) => {
    res.json(orders);
  });

  function formatCurrencyNode(amount: number) {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0,
    }).format(amount);
  }

  function buildInvoiceMessage(order: any) {
    const companyName = "PUNTOS DE SABOR S.A.S";
    const companyNit = "900.123.456-7";
    const helloName = order.customerName?.trim() || "Cliente";
    const date = new Date(order.createdAt).toLocaleDateString('es-CO', { day: '2-digit', month: '2-digit', year: 'numeric' });
    const invNum = order.code.replace('#', '').padStart(4, '0');

    const lines = [
      `Hola ${helloName}, 👋`,
      "",
      `Gracias por tu compra. Te compartimos los datos de tu Factura de Venta No. ${invNum} emitida por ${companyName} – NIT ${companyNit}.`,
      "",
      `📅 Fecha de expedición: ${date}`,
      "",
      "🍽 Detalle de tu pedido:",
    ];

    order.items.forEach((it: any) => {
      lines.push(`${it.name}  ..............  ${formatCurrencyNode(it.price * it.quantity)}`);
    });

    lines.push("");
    lines.push(`IVA (19%) ............................ ${formatCurrencyNode(order.tax)}`);
    lines.push(`💰 Total a pagar: ${formatCurrencyNode(order.total)}`);
    lines.push("");
    lines.push(`⚖ ${companyName.split(' S.A.S')[0]} es responsable del IVA y agente retenedor.`);
    lines.push("");
    lines.push("Si necesitas imprimir, personalizar o descargar tu factura, ve al siguiente link:");
    lines.push("");
    lines.push("Gracias por preferirnos. ¡Esperamos que disfrutes tu pedido! 😊😊");

    return lines.join('\n');
  }

  async function sendWhatsApp(to: string, body: string) {
    const sid = process.env.TWILIO_ACCOUNT_SID;
    const token = process.env.TWILIO_AUTH_TOKEN;
    const fromEnv = process.env.TWILIO_WA_FROM || "whatsapp:+14155238886";

    if (!sid || !token) {
      console.warn("Twilio credentials not configured. Skipping WhatsApp send.");
      return { success: false, error: "Credentials missing" };
    }

    let formattedFrom = fromEnv.trim().replace(/\s/g, ''); // Remove all whitespace
    if (!formattedFrom.startsWith('whatsapp:')) {
      formattedFrom = `whatsapp:${formattedFrom.startsWith('+') ? '' : '+'}${formattedFrom}`;
    }

    // Normalize phone number (E.164)
    let digits = to.replace(/\D/g, '');
    if (!digits) {
      console.error("Invalid phone number provided:", to);
      return { success: false, error: "Número inválido" };
    }
    
    // Auto-detect Colombian 10-digit number
    if (digits.length === 10) {
      digits = '57' + digits;
    }
    
    const formattedTo = `whatsapp:+${digits}`;

    console.log(`Sending WhatsApp message FROM [${formattedFrom}] TO [${formattedTo}] via Twilio`);

    const url = `https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`;
    const auth = Buffer.from(`${sid}:${token}`).toString('base64');

    const params = new URLSearchParams();
    params.set('From', formattedFrom);
    params.set('To', formattedTo);
    params.set('Body', body);

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: params.toString()
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error(`Twilio API Error details:`, JSON.stringify(errorData, null, 2));
        return { success: false, error: errorData.message || response.statusText };
      }

      const result = await response.json();
      console.log("Twilio Message Status:", result.status, "SID:", result.sid);
      return { success: true, sid: result.sid };
    } catch (error) {
      console.error("Fetch error sending WhatsApp:", error);
      return { success: false, error: String(error) };
    }
  }

  app.post("/api/orders", async (req, res) => {
    lastOrderNum++;
    const order = {
      ...req.body,
      id: Math.random().toString(36).substr(2, 9),
      code: `#${lastOrderNum.toString().padStart(3, '0')}`,
      status: 'PENDING',
      createdAt: new Date().toISOString()
    };
    
    orders.push(order);
    
    // Send WhatsApp Invoice and wait for results
    const message = buildInvoiceMessage(order);
    const waResult = await sendWhatsApp(order.customerPhone, message);

    if (!waResult.success) {
      // Order is saved, but notify about WA failure
      return res.status(201).json({ ...order, whatsappError: waResult.error });
    }

    res.status(201).json(order);
  });

  app.patch("/api/orders/:id/status", (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const orderIndex = orders.findIndex(o => o.id === id);
    if (orderIndex !== -1) {
      orders[orderIndex].status = status;
      return res.json(orders[orderIndex]);
    }
    res.status(404).json({ error: "Order not found" });
  });

  app.delete("/api/orders/:id", (req, res) => {
    const { id } = req.params;
    orders = orders.filter(o => o.id !== id);
    res.status(204).send();
  });

  app.delete("/api/orders", (req, res) => {
    orders = [];
    lastOrderNum = 0;
    res.status(204).send();
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production serving
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
